
(function onPageLoad() {
  // const url = document.location.href;
  debouncedHandleHistoryStateUpdated()
})()