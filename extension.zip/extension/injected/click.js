
function onExtensionIconClick() {
  renderBookmarkPopup()
}

onExtensionIconClick()
